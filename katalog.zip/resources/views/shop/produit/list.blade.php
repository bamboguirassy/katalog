@extends('base')

@section('title',$shop->nom." - Catalogue");

@section('description',"")

@section('body')

@endsection