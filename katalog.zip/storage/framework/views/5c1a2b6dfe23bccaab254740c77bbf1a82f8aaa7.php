<?php $__env->startComponent('mail::message'); ?>
[![Logo Bambo GROUP](https://katalog.bambogroup.net/assets/images/bambogroup-50x50.jpg "Logo Bambo GROUP")](https://katalog.bambogroup.net/assets/images/bambogroup.jpg)


Bonjour **<?php echo e($user->name); ?>**,
Bienvenue sur la plateforme ***<?php echo e(config('app.name')); ?>***.
Votre compte est créé avec succès. Veuillez trouver ci-dessous vos identifiants de connexion: 
- Email: **<?php echo e($user->email); ?>**
- Mot de passe (à ne surtout pas partager): **<?php echo e($password); ?>**

Vous pourrez naviguer avec ce compte sur toutes les boutiques de la plateforme, passer des commandes et suivre vos commandes.

Cordialement.

---
**Katalog** est un produit de [Bambo GROUP](https://bambogroup.net)
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/emails/user/new-account.blade.php ENDPATH**/ ?>