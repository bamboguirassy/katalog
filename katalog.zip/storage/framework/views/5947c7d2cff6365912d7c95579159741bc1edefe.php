

<?php $__env->startSection('icon'); ?>
<?php echo e(asset('assets/images/produits-meta.jpeg')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title',"Catégorie de produit - ".$shop->nom); ?>;

<?php $__env->startSection('description',"Paramétrer les catégories de produits de la boutique..."); ?>

<?php $__env->startSection('body'); ?>
<section data-bs-version="5.1" class="section-table cid-sIs6gkDQqC" id="table1-1k">
    <div class="mbr-overlay" style="opacity: 0.8; background-color: rgb(255, 255, 255);">
    </div>

    <div class="container container-table">
        <h2 class="mbr-section-title mbr-fonts-style align-center pb-3 display-2">
            <br>Catégories</h2>
        <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-2 display-7">
            Quelles sont les catégories de produits que vous vendez dans votre boutique ? <br>
            Vous pouvez ajouter les produits juste après avoir créé les catégories de produits en cliquant sur "<em>
                <a href="<?php echo e(route('shop.catalogue',compact('shop'))); ?>" class="text-primary"><strong>Gérer le catalogue
                        des produits</strong></a></em>".</h3>
        <div class="table-wrapper">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <section class="form cid-sIs9blqdbr" id="formbuilder-1m">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8 mx-auto mbr-form">
                                    <!--Formbuilder Form-->
                                    <form action="<?php echo e(route('shop.categorie.store',compact('shop'))); ?>" method="POST"
                                        class="mbr-form form-with-styler" data-form-title="Form Name">
                                        <?php echo method_field('post'); ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-row">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div data-form-alert-danger="" class="alert alert-danger col-12">
                                                <?php echo e($message); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="dragArea form-row">
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <h4 class="mbr-fonts-style display-5">Ajouter une catégorie</h4>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <hr>
                                            </div>
                                            <div data-for="nom" class="col-lg-12 col-md-12 col-sm-12 form-group">
                                                <label for="nom-formbuilder-1m"
                                                    class="form-control-label mbr-fonts-style display-7">Catégorie</label>
                                                <input value="<?php echo e(old('nom')); ?>" type="text" name="nom"
                                                    placeholder="Nom catégorie" data-form-field="nom"
                                                    class="form-control display-7" required="required" value=""
                                                    id="nom-formbuilder-1m">
                                            </div>
                                            <div data-for="categorie_id"
                                                class="col-lg-12 col-md-12 col-sm-12 form-group">
                                                <label for="categorie_id-formbuilder-1m"
                                                    class="form-control-label mbr-fonts-style display-7">Catégorie
                                                    parente (optionnel)</label>
                                                <select name="categorie_id" data-form-field="categorie_id"
                                                    class="form-control display-7" id="categorie_id-formbuilder-1m">
                                                    <option value="" style="text-align: center;">---</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->nom); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div data-for="description"
                                                class="col-lg-12 col-md-12 col-sm-12 form-group">
                                                <label for="description-formbuilder-1m"
                                                    class="form-control-label mbr-fonts-style display-7">Description</label>
                                                <textarea name="description" placeholder="Description catégorie"
                                                    data-form-field="description" class="form-control display-7"
                                                    id="description-formbuilder-1m"><?php echo e(old('description')); ?></textarea>
                                            </div>
                                            <div class="col">
                                                <button type="submit"
                                                    class="btn btn-primary display-7">Enregistrer</button>
                                            </div>
                                        </div>
                                    </form>
                                    <!--Formbuilder Form-->
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="container scroll">
                        <table class="table isSearch" cellspacing="0" data-empty="No matching records found">
                            <thead>
                                <tr class="table-heads">
                                    <th class="head-item mbr-fonts-style display-7">Nom</th>
                                    <th class="head-item mbr-fonts-style display-7">Active</th>
                                    <th class="head-item mbr-fonts-style display-7">Parent</th>
                                    <th class="head-item mbr-fonts-style display-7">Description</th>
                                    <th class="head-item mbr-fonts-style display-7">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="body-item mbr-fonts-style display-7"><?php echo e($categorie->nom); ?></td>
                                <td class="body-item mbr-fonts-style display-7">
                                    <?php if($categorie->active): ?>
                                    <b>Oui</b>
                                    <?php else: ?>
                                    <div class="alert alert-primary" role="alert">
                                        <strong>Non</strong>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td class="body-item mbr-fonts-style display-7">
                                    <?php if($categorie->parent!=null): ?>
                                    <?php echo e($categorie->parent->nom); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="body-item mbr-fonts-style display-7"><?php echo e($categorie->description); ?></td>
                                <td class="body-item mbr-fonts-style display-7">
                                    <form action="<?php echo e(route('shop.categorie.destroy',compact('categorie','shop'))); ?>"
                                        method="post">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button style="background: red;" method="submit" class="btn btn-sm mbr-white">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/shop/categorie/list.blade.php ENDPATH**/ ?>