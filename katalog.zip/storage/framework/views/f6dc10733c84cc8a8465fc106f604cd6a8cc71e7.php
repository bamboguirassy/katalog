<?php $__env->startComponent('mail::message'); ?>
[![Logo <?php echo e($commande->shop->nom); ?>](<?php echo e(asset('storage/shops/'.$commande->shop->logo)); ?> "Logo <?php echo e($commande->shop->nom); ?>")](<?php echo e(asset('storage/shops/'.$commande->shop->logo)); ?>)

Bonjour ***<?php echo e($commande->user->name); ?>***,
Bienvenue chez **<?php echo e($commande->shop->nom); ?>**.
Nous avons reçu avec succès votre commande numéro **<?php echo e($commande->numero); ?>** passée dans notre boutique.
Nous allons vous revenir très prochainement.
Cordialement.

---
**Katalog** est un produit de [Bambo GROUP](https://bambogroup.net)
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/emails/commande/new.blade.php ENDPATH**/ ?>