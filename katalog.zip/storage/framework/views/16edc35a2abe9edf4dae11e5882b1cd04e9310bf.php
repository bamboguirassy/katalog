

<?php $__env->startSection('title','Mon panier - '.$shop->nom); ?>;

<?php $__env->startSection('description',"Votre panier chez la boutique ".$shop->nom); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-12">
        <section data-bs-version="5.1" class="content1 cid-sITwirkIJg" id="content01-38">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-12 col-lg md-pb text-white">
                        <div class="text-wrapper">
                            <h3 class="mbr-section-title align-left mbr-fonts-style mb-5 display-1">Mon panier chez
                                <?php echo e($shop->nom); ?>.</h3>
                            <p class="mbr-text mbr-fonts-style align-left mb-5 display-7">
                                Retrouvez l'ensemble des produits que vous avez ajouter à votre panier afin de finaliser
                                la commande.</p>
                            <div class="link-wrap pt-2">
                                <a href="<?php echo e(route('shop.home',compact('shop'))); ?>">
                                    <span class="link mbr-fonts-style display-4">
                                        <strong>Continuer mes
                                            achats</strong>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-4">
                        <div class="image-wrapper">
                            <img class="w-100" src="<?php echo e(asset('uploads/shops/'.$shop->logo)); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php if(isset($panier)): ?>
        <section data-bs-version="5.1" class="content3 cid-sITwhqEfMF" id="content03-37">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="counter-container col-md-12 col-lg-">
                        <h3 class="mbr-section-title mbr-fonts-style mb-2 display-5">Produit(s) sélectionné(s)</h3>
                        <h4 class="mbr-section-subtitle mbr-fonts-style mb-5 display-7">Voici la liste des produits
                            ajoutés à votre panier.<br>Vous pouvez
                            <a href="<?php echo e(route('shop.home',compact('shop'))); ?>"
                                class="text-primary"><strong><em>poursuivre vos
                                        achats</em></strong></a> si vous souhaitez ajouter plus de produits</h4>
                        <?php $__currentLoopData = $panier->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row icon first">
                            <div class="col-lg-2">
                                <form
                                    action="<?php echo e(route('shop.panier.produit.delete',['shop'=>$shop,'paproduit'=>$produit])); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Enlever</button>
                                </form>
                            </div>
                            <div class="col-lg-2">
                                <p class="mbr-text mbr-fonts-style display-4">
                                    <?php echo e($produit->produit->nom); ?>

                                </p>
                                <?php if(count($produit->produit->attributValues)>0): ?>
                                <div class="pb-2">
                                    <?php $__currentLoopData = $produit->produit->attributValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($attributValue->valeurAttributProduit->valeurAttribut->attribut->nom); ?> :</span>
                                    <?php if($attributValue->valeurAttributProduit->valeurAttribut->attribut->type=='couleur'): ?>
                                     <span
                                        style="border: 2px solid #1C73BA; background-color: <?php echo e($attributValue->valeurAttributProduit->valeurAttribut->valeur); ?>">
                                    &nbsp; &nbsp;
                                    </span>
                                    <?php else: ?>
                                    <span
                                        style="padding: 2px; border: 2px solid #1C73BA;"><?php echo e($attributValue->valeurAttributProduit->valeurAttribut->valeur); ?></span>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-2">
                                <p class="mbr-text mbr-fonts-style display-4">
                                    <?php echo e($produit->produit->prixUnitaire); ?> FCFA<br></p>
                            </div>
                            <div class="col-lg-4">
                                <p class="mbr-text mbr-fonts-style display-4">
                                    <?php echo e($produit->quantite); ?> unité(s)</p>
                            </div>
                            <div class="col-lg-2">
                                <p class="mbr-text mbr-fonts-style display-4">
                                    <?php echo e($produit->produit->prixUnitaire*$produit->quantite); ?> FCFA</p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row icon">
                            <div class="col-lg-8">

                            </div>
                            <div class="col-lg-2">
                                Total
                            </div>
                            <div class="col-lg-2">
                                <p class="mbr-text mbr-fonts-style display-4">
                                    <?php echo e($montant); ?> FCFA</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mt-2">
                        <?php if(empty($panier->produits)): ?>
                        <h3>Votre panier est vide...</h3>
                        <?php else: ?>
                        <form action="<?php echo e(route('shop.panier.convert', compact('shop','panier'))); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <button class="btn btn-primary">Envoyer la commande</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </section>
        <?php else: ?>
        <h3 class="text-center b">Votre panier est vide...</h3>
        <?php endif; ?>

        <section data-bs-version="5.1" class="info3 cid-sIYsC74kwn" id="info3-3c">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="card col-12 col-lg-10">
                        <div class="card-wrapper">
                            <div class="card-box align-center">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section data-bs-version="5.1" class="content4 cid-sIYrSkcD8K" id="extContacts4-3b">

            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h4 class="card-title mbr-semibold pb-2 align-left mbr-fonts-style display-2">
                            <?php echo e($shop->nom); ?>

                        </h4>
                    </div>

                    <div class="col-lg-8">

                        <p class="mbr-text pb-2 align-left mbr-fonts-style display-4">
                            <?php echo e($shop->description); ?>

                        </p>
                    </div>
                    <div class="col-lg-4">
                        <p class="items items-col align-left mbr-fonts-style display-4">
                            <strong>EMAIL:</strong> &nbsp;<a
                                href="mailto:<?php echo e($shop->email); ?>"><?php echo e($shop->email); ?></a><br><strong>CATEGORIE:</strong>
                            &nbsp;<?php echo e($shop->categorie->nom); ?><br>
                            <strong>TELEPHONES:
                            </strong>&nbsp;
                            <a href="tel:<?php echo e($shop->telephonePrimary); ?>"
                                class="text-primary"><?php echo e($shop->telephonePrimaire); ?></a>
                            <?php if(isset($shop->telephoneSecondaire)): ?>
                            / <a href="tel:<?php echo e($shop->telephoneSecondaire); ?>"
                                class="text-primary"><?php echo e($shop->telephoneSecondaire); ?></a>
                            <?php endif; ?>
                            <br>
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/user/panier.blade.php ENDPATH**/ ?>