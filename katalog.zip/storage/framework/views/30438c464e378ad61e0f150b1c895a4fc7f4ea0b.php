

<?php $__env->startSection('title',$shop->nom." - Catalogue"); ?>;

<?php $__env->startSection('description',""); ?>

<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views\shop\produit\list.blade.php ENDPATH**/ ?>