

<?php $__env->startSection('title',"Détails produit - ".$produit->nom); ?>;

<?php $__env->startSection('description',$produit->description); ?>

<?php $__env->startSection('body'); ?>
<style>
    .hedding {
        font-size: 20px;
        color: #ab8181`;
    }

    .left-side-product-box img {
        width: 100%;
    }

    .left-side-product-box .sub-img img {
        margin-top: 5px;
        width: 83px;
        height: 100px;
    }

    .right-side-pro-detail span {
        font-size: 15px;
    }

    .right-side-pro-detail p {
        font-size: 25px;
        color: #a1a1a1;
    }

    .right-side-pro-detail .price-pro {
        color: #E45641;
    }

    .right-side-pro-detail .tag-section {
        font-size: 18px;
        color: #5D4C46;
    }

    .pro-box-section .pro-box img {
        width: 100%;
        height: 200px;
    }

    @media (min-width:360px) and (max-width:640px) {
        .pro-box-section .pro-box img {
            height: auto;
        }
    }
</style>
<section ng-cloak ng-controller="ProduitShowController" ng-init="init(<?php echo e($produit); ?>,<?php echo e($attributs); ?>)">
    <div class="container mt-3">
        <div class="col-lg-12 border p-3 main-section bg-white">
            <div class="row m-0">
                <div class="col-lg-4 left-side-product-box pb-3">
                    <img src="<?php echo e(asset('uploads/produits/images/'.$produit->imageCouverture->nom)); ?>"
                        class="border p-3">
                </div>
                <div class="col-lg-8">
                    <div class="right-side-pro-detail border p-3 m-0" ng-init="addAttribut=false">
                        <div class="row">
                            <div class="col-lg-12">
                                <?php $__currentLoopData = $produit->categorieProduits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorieProd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="font-size: 22px;"><a href="<?php echo e(route('shop.categorie.show',['categorie'=>$categorieProd,'shop'=>$shop])); ?>"><?php echo e($categorieProd->categorie->nom); ?></a> >></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p class="m-0 p-0 mt-3">[[ produit.nom ]]</p>
                            </div>
                            <div class="col-lg-12">
                                <p class="m-0 p-0 price-pro">[[produit.prixUnitaire]] FCFA</p>
                                <hr class="p-0 m-0">
                            </div>
                            <div class="col-lg-12 pt-2 pb-2">
                                <h5>Détails Produit</h5>
                                <span>[[ produit.description ]]</span>
                                <hr class="m-0 pt-2 mt-2">
                            </div>
                            <div class="col-lg-12" ng-init="attribut.add=false"
                                ng-repeat="attribut in produit.attributs" style="margin-top: 3px;">
                                <p class="tag-section"
                                    ng-init="attribut.original = (attributs|where:{id:attribut.attribut.id}|first)">
                                    <button ng-show="produit.variants.length<1" ng-click="removeAttribute(attribut)"
                                        class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                    <strong>[[attribut.attribut.nom]] : </strong>
                                    <span ng-repeat="valeur in attribut.valeurs"
                                        title="[[ valeur.valeur_attribut.nom ]]"
                                        style="border: 2px solid #1c73ba; padding: 3px; margin-left: 3px;">
                                        [[valeur.valeur_attribut.attribut.type=='texte'?valeur.valeur_attribut.valeur:valeur.valeur_attribut.nom]]
                                        <b ng-show="produit.variants.length<1" ng-click="removeValue(valeur)"
                                            style="font-size: 20px; color: red;">x</b>
                                    </span>
                                    <button ng-if="!attribut.add && produit.variants.length<1"
                                        ng-click="attribut.add = !attribut.add" class="btn btn-primary btn-sm">
                                        <i class="fa fa-plus" aria-hidden="true"></i></button>
                                    <div class="row">
                                        <div class="col-12 col-lg-8">
                                            <select ng-model="attribut.newValues" multiple="multiple"
                                                class="form-control" ng-if="attribut.add" name="attribut[[attribut.id]]"
                                                id="attribut[[attribut.id]]">
                                                <option
                                                    ng-hide="(attribut.valeurs|map:'valeur_attribut.id')|contains:originalVal.id"
                                                    ng-repeat="originalVal in attribut.original.valeurs"
                                                    value="[[originalVal.id]]">[[
                                                    originalVal.nom ]]</option>
                                            </select>
                                        </div>
                                        <div class="col-12 col-lg-4">
                                            <button ng-click="addNewValuesToAttribute(attribut)" ng-if="attribut.add"
                                                class="btn btn-secondary btn-sm">
                                                <i class="fa fa-save" aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                </p>
                            </div>
                            <div class="col-12" ng-show="!addAttribut && produit.variants.length<1">
                                <button ng-click="addAttribut = !addAttribut" type="button"
                                    class="btn btn-primary">Ajouter d'autres attributs</button>
                            </div>
                            <form method="post"
                                action="<?php echo e(route('shop.attributproduit.save.multiple',compact('shop','produit'))); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div ng-if="addAttribut" class="col-lg-12 col-md-12 col-sm-12 form-group"
                                    data-for="selectedAttr">
                                    <div class="form-control-label">
                                        <label for="visible-formbuilder-14[[$index]]"
                                            class="mbr-fonts-style display-7">Selectionner les attributs</label>
                                    </div>
                                    <ng-container ng-repeat="attr in attributs">
                                        <div ng-if="!((produit.attributs|map:'attribut.id')|contains:attr.id)"
                                            class="form-check form-check-inline">
                                            <input ng-click="toggleAttrSelection(attr)" type="checkbox"
                                                name="selectedAttrs[]" data-form-field="selectedAttr"
                                                class="form-check-input display-7" value="[[attr.id]]"
                                                id="visible-formbuilder-14[[$index]]">
                                            <label class="form-check-label display-7">[[attr.nom]]</label>
                                        </div>
                                    </ng-container>
                                </div>
                                <div ng-repeat="selectedAttr in selectedAttrs"
                                    class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="category">
                                    <label for="category-formbuilder-14[[selectedAttr.id]]"
                                        class="form-control-label mbr-fonts-style display-7">[[selectedAttr.nom]]</label>
                                    <select required="required" name="[[selectedAttr.nom]][]" multiple="multiple"
                                        data-form-field="category" class="form-control display-7"
                                        id="category-formbuilder-14[[selectedAttr.id]]">
                                        <option ng-repeat="valeur in selectedAttr.valeurs" value="[[valeur.id]]">
                                            [[valeur.nom]]</option>
                                    </select>
                                </div>
                                <div class="col-12" ng-show="addAttribut && selectedAttrs.length>0">
                                    <button type="submit" class="btn btn-primary">Sauvegarder</button>
                                </div>
                            </form>
                            <hr class="m-0 pt-2 mt-2">
                            <div class="col-lg-12 mt-3">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <a href="<?php echo e(route('shop.produit.edit',compact('produit','shop'))); ?>"
                                            class="btn btn-warning w-100 m-0 p-0">Modifier</a>
                                    </div>
                                    <div class="col-lg-6">
                                        <form style="display: inline;"
                                            action="<?php echo e(route('shop.produit.destroy',compact('shop','produit'))); ?>"
                                            method="POST">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button style="display: inline;"
                                                class="btn btn-danger m-0 p-0 w-100 mbr-white">
                                                Supprimer
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12" ng-show="produit.variants.length<1 && produit.attributs.length>0">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Générer les combinaisons</h4>
                            <p class="card-text">
                                Cliquez sur le bouton ci-dessous pour générer et paramétrer l'ensemble des combinaisons
                                selons les attributs du produit. <br>
                                Une fois les combinaisons générées, vous ne pourrez plus ajouter de nouveaux
                                attributs...
                            </p>
                        </div>
                        <div class="card-body">
                            <button ng-click="generateCombination()" class="card-link btn btn-primary">Générer les
                                combinaisons</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12" ng-show="produit.variants.length>0">
                    <h4>Gérer les combinaisons de produit</h4>
                    <div class="row">
                        <div class="col-12 mb-3" ng-repeat="variant in produit.variants"
                            style="border-left: 2px solid darkgray;">
                            <strong>
                                <i>[[$index+1]].</i> [[produit.nom]] -
                                [[(variant.attribut_values|map:'valeur_attribut_produit.valeur_attribut.nom')|join:' x
                                ']]
                            </strong>
                            <button ng-click="removeVariant(variant)"
                                title="Vous pouvez supprimer les variants qui n'ont pas d'importance pour le produit..."
                                class="fa fa-2x fa-trash-o pull-right text-danger" aria-hidden="true"></button>
                            <button ng-show="variant.configured" ng-click="variant.configured = false"
                                class="fa fa-2x fa-pencil pull-right text-default" aria-hidden="true"></button>
                            <hr style="margin-top: 0px;">
                            <form ng-submit="updateVariant(variant)" ng-show="!variant.configured">
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <div class="form-group">
                                            <label for="prixUnitaire[[$index]]">Prix Unitaire</label>
                                            <input ng-model="variant.prixUnitaire" required="required" type="number"
                                                name="prixUnitaire[[$index]]" id="prixUnitaire[[$index]]"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <div class="form-group">
                                            <label for="quantite[[$index]]">Quantité</label>
                                            <input ng-model="variant.quantite" required="required" type="number"
                                                name="quantite[[$index]]" id="quantite[[$index]]" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit"
                                            class="btn btn-sm btn-primary pull-right" style="margin-left: 3px;">Enregistrer</button>
                                        <button ng-click="variant.configured=true" type="submit"
                                            class="btn btn-sm btn-secondary pull-right">Annuler</button>
                                    </div>
                                </div>
                            </form>
                            <table class="table">
                                <tr ng-show="variant.configured">
                                    <th>Prix unitaire</th>
                                    <td>[[variant.prixUnitaire]] FCFA</td>
                                    <th>Quantité</th>
                                    <td>[[variant.quantite]] élement(s)</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label class="form-control-label mbr-fonts-style display-7">Ajouter
                                                        des
                                                        photos</label>
                                                    <form name="addVariantImageForm"
                                                        action="[['/'+shop.pseudonyme+'/produit/add-images/'+variant.id]]"
                                                        method="POST" enctype="multipart/form-data">
                                                        <?php echo method_field('post'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="row">
                                                            <div class="col-12 col-lg-6">
                                                                <input change="handleVariantImagesChange()"
                                                                    ng-model="variant.photos" required="required"
                                                                    type="file" multiple="multiple" accept="image/*"
                                                                    name="photos[]" required="required"
                                                                    class="form-control display-7"
                                                                    id="produitVariantImageInput">
                                                            </div>
                                                            <div class="col-12 col-lg-6">
                                                                <button type="submit" class="btn btn-primary">Téléverser</button>
                                                            </div>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" ng-show="variant.configured">
                                            <div class="col-12 col-md-6 col-lg-3" ng-repeat="image in variant.images">
                                                <img style="height: 210px;" src="/uploads/produits/images/[[image.nom]]"
                                                    alt="" srcset="">
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <section data-bs-version="5.1" class="gallery2 cid-sIDTM1YNga" id="gallery2-1t">
        <div class="container">
            <div class="mbr-section-head">
                <h5 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 display-2">
                    Gérer la galerie d'image...</h5>
            </div>
            <div class="row mt-2">
                <div class="col-12">
                    <h3>Ajouter d'autres images du produit</h3>
                </div>
                <hr>
                <div class="col-12">
                    <form action="<?php echo e(route('shop.produit.add.images', compact('shop','produit'))); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div data-for="photos" class="col-lg-12 col-md-12 col-sm-12 form-group">
                            <label for="photos-formbuilder-14"
                                class="form-control-label mbr-fonts-style display-7">Sélectionner des photos</label>
                            <input value="<?php echo e(old('photos')); ?>" type="file" multiple="multiple" accept="image/*"
                                name="photos[]" placeholder="Sélectionner des photos du produit"
                                data-form-field="photos" required="required" class="form-control display-7" value=""
                                id="photos-formbuilder-14">
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12">
                        </div>
                        <button name="" id="" class="btn btn-primary" role="button">Téléverser</button>
                    </form>
                </div>
                <hr>
                <?php $__currentLoopData = $produit->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item features-image сol-12 col-md-4 col-lg-3">
                    <div class="item-wrapper">
                        <div class="item-img">
                            <img src="<?php echo e(asset('uploads/produits/images/'.$image->nom)); ?>">
                        </div>
                        <div class="mbr-section-btn item-footer mt-2">
                            <?php if($image->id!=$produit->imageCouverture->id): ?>
                            <form style="display: inline; float: right;"
                                action="<?php echo e(route('shop.image.destroy',compact('image','shop'))); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button style="background: red; display: inline; margin-left: 3px;"
                                    class="btn item-btn mbr-white">
                                    <span class="mobi-mbri mobi-mbri-trash mbr-iconfont mbr-iconfont-btn"></span>
                                </button>
                            </form>
                            <form style="display: inline; float: right;"
                                action="<?php echo e(route('shop.produit.update.couverture.photo', compact('shop','image'))); ?>"
                                method="post">
                                <?php echo method_field('post'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn item-btn btn-info">Mettre en couverture</button>
                            </form>
                            <?php else: ?>
                            <span class="btn item-btn btn-info" style="color: green;">Actuellement en couverture</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/shop/produit/show.blade.php ENDPATH**/ ?>