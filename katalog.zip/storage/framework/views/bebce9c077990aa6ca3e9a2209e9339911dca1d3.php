

<?php $__env->startSection('icon'); ?>
<?php echo e(asset('assets/images/produits-meta.jpeg')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title',"Détails Boutique - ".$shop->nom); ?>;

<?php $__env->startSection('description',$shop->description); ?>

<?php $__env->startSection('body'); ?>
<section data-bs-version="5.1" class="content5 cid-sIqITZHSZd" id="extContacts5-19">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="card-img">
                    <span class="category-item"><?php echo e($shop->categorie->nom); ?></span>
                    <img style="max-height: 500px; object-fit: cover;" src="<?php echo e(asset('storage/shops/'.$shop->logo)); ?>"
                        alt="">
                </div>
                <form action="<?php echo e(route('shop.update.shop.logo',compact('shop'))); ?>" method="POST" class="mbr-form form-with-styler"
                    data-form-title="boutiqueNewForm" enctype="multipart/form-data" id="shopLogoUpdate">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div hidden="hidden" data-form-alert="" class="alert alert-success col-12"></div>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-form-alert-danger="" class="alert alert-danger col-12"><?php echo e($message); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dragArea form-row">
                        <div class="col-lg-6 col-md-12 col-sm-12 form-group" style="" data-for="logo">
                            <label for="logo-formbuilder-q"
                                class="form-control-label mbr-fonts-style display-7 mbr-white">Changer le logo</label>
                            <input placeholder="Changer logo" value="<?php echo e(old('logo')); ?>" type="file" accept="image/*"
                                name="logo" data-form-field="logo" class="form-control display-7" value=""
                                id="logo-formbuilder-q">
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4">
                <h4 class="card-title mbr-semibold pb-2 align-left mbr-fonts-style display-5"><br>
                    <?php echo e($shop->nom); ?>

                </h4>
                <p class="mbr-text align-left mbr-fonts-style display-4">
                    <?php echo e($shop->description); ?>

                </p>
                <p class="items items-col align-left mbr-fonts-style display-4">
                    <strong>CODE UNIQUE:</strong> &nbsp;<?php echo e($shop->pseudonyme); ?><br>
                    <strong>CATEGORIE:</strong> &nbsp;<?php echo e($shop->categorie->nom); ?><br>
                    <strong>DATE ACCES:</strong>&nbsp;<?php echo e(date_format($shop->created_at,'d M, Y')); ?><br></p>
                <div class="social-list pt-2 align-left">
                    <p class="items align-left mbr-fonts-style display-4">
                        <strong>PARTAGER:&nbsp;</strong>
                    </p>
                    <?php if(isset($shop->twitter)): ?>
                    <div class="soc-item">
                        <a href="<?php echo e($shop->twitter); ?>" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon"></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($shop->facebook)): ?>
                    <div class="soc-item">
                        <a href="<?php echo e($shop->facebook); ?>" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($shop->instagram)): ?>
                    <div class="soc-item">
                        <a href="<?php echo e($shop->instagram); ?>" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($shop->linkedin)): ?>
                    <div class="soc-item">
                        <a href="<?php echo e($shop->linkedin); ?>" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-linkedin socicon"></span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->type=='owner' && auth()->user()->shop->id==$shop->id): ?>
                <div class="col-12">
                    <button class="btn mt-2 mbr-white" style="background: orange;">Modifier &nbsp; <i
                            class="fa fa-edit"></i></button>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="contacts1 cid-sIrPBkLOUh" id="contacts01-1e">
    <div class="container">
        <div class="mbr-section-head pb-4">
            <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">Contacts
            </h3>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            Téléphone Primaire
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <a href="tel:<?php echo e($shop->telephonePrimaire); ?>"
                                class="text-success"><?php echo e($shop->telephonePrimaire); ?></a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            Email
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <a href="mailto:<?php echo e($shop->email); ?>" class="text-success"><?php echo e($shop->email); ?></a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-globe mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            Adresse
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <?php echo e($shop->adresse); ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="card col-12 col-md-6">
                <div class="card-wrapper">
                    <div class="image-wrapper">
                        <span class="mbr-iconfont mobi-mbri-bulleted-list mobi-mbri"></span>
                    </div>
                    <div class="text-wrapper">
                        <h6 class="card-title mbr-fonts-style mb-1 display-5">
                            Téléphone sécondaire
                        </h6>
                        <p class="mbr-text mbr-fonts-style display-7">
                            <?php if(isset($shop->telephoneSecondaire)): ?>
                            <a href="tel:<?php echo e($shop->telephoneSecondaire); ?>"
                                class="text-success"><?php echo e($shop->telephoneSecondaire); ?></a>
                            <?php else: ?>
                            Non renseigné
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/shop/details.blade.php ENDPATH**/ ?>