<?php $__env->startComponent('mail::message'); ?>
[![Logo Bambo GROUP](https://katalog.bambogroup.net/assets/images/bambogroup-50x50.jpg "Logo Bambo GROUP")](https://katalog.bambogroup.net/assets/images/bambogroup.jpg)

Bonjour,
Votre boutique ***<?php echo e($shop->nom); ?>*** vient d'être créée avec succès sur la plateforme **<?php echo e(config('app.name')); ?>**.
Merci de faire les opérations suivantes afin de commencer à profiter pleinement desde votre boutique :
1. Accéder à votre boutique avec votre compte
2. Ajouter les differentes catégories de produits que vous vendez
3. Gérer le catalogue en ajoutant l'ensemble des produits avec des images
4. Et partager la boutique sur les réseaux sociaux, avec vos amis et vos clients
5. Commencer à recevoir vos commande

Vos informations sont les suivantes : 
- Lien d'accès à la boutique : [<?php echo e(request()->getHttpHost().'/'.$shop->pseudonyme); ?>](<?php echo e(request()->getHttpHost().'/'.$shop->pseudonyme); ?>)
- Email : **<?php echo e($shop->email); ?>**
- Mot de passe *(à ne surtout pas partager)* : **<?php echo e($password); ?>** 
> Pour tout besoin, n'hesitez pas à nous contacter sur <contact@bammbogroup.net>

Cordialement.

---
**<?php echo e(config('app.name')); ?>** est un produit de [Bambo GROUP](https://bambogroup.net)

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/emails/shop/created.blade.php ENDPATH**/ ?>