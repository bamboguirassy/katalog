

<?php $__env->startSection('title',$shop->nom." - Catalogue"); ?>;

<?php $__env->startSection('description',""); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-12">
        <section data-bs-version="5.1" class="info3 cid-sIqCr2MrZ5" id="info3-y">
            <div class="mbr-overlay" style="opacity: 0.6; background-color: #1C73BA;">
            </div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="card col-12 col-lg-10">
                        <div class="card-wrapper">
                            <div class="card-box align-center">
                                <h4 class="card-title mbr-fonts-style align-center mb-4 display-2">
                                    <strong>Mon
                                        catalogue</strong></h4>
                                <p class="mbr-text mbr-fonts-style mb-4 display-7">
                                    Gérez votre catalogue en y ajoutant vos produits ou en les mettant à jour.</p>
                                <div class="mbr-section-btn mt-3">
                                    <a class="btn btn-primary display-4"
                                        href="<?php echo e(route('shop.produit.create',compact('shop'))); ?>"><span
                                            class="mbri-plus mbr-iconfont mbr-iconfont-btn"></span>Ajouter un
                                        produit&nbsp;</a>
                                    <a class="btn btn-primary display-4"
                                        href="<?php echo e(route('shop.categorie.index',compact('shop'))); ?>"><span
                                            class="mbri-info mbr-iconfont mbr-iconfont-btn"></span>Gérer les catégories
                                        de produits&nbsp;</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section data-bs-version="5.1" class="gallery1 cid-sIpMwjCas3" id="gallery1-8">
            <div class="container">
                <div class="mbr-section-head">
                    <h5 class="mbr-section-subtitle mbr-fonts-style align-center mb-0 display-7">
                        Ceci est la liste des produits que vous avez ajouté à votre stock.</h5>
                    <?php if(count($produits)<1): ?> <div
                        style="height: 100px; line-height: 100px; font-size: 25px; background: white; color: #196B86; text-align: center; float: center;">
                        La boutique est vide pour l'instant !
                </div>
                <?php endif; ?>
            </div>
            <div class="row content-margin">
                <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item features-image сol-12 col-md-6 col-lg-4">
                    <div class="item-wrapper">
                        <div class="item-img">
                            <span class="category-badge"><?php echo e($produit->categorie->nom); ?></span>
                            <span class="price-badge"><?php echo e($produit->prixUnitaire); ?> FCFA</span>
                            <a href="<?php echo e(route('shop.produit.show',compact('produit','shop'))); ?>">
                                <img src="<?php echo e(asset('uploads/produits/images/'.$produit->imageCouverture->nom)); ?>"
                                    alt="<?php echo e($produit->nom); ?> Photo">
                            </a>
                        </div>
                        <div class="item-content">
                            <h5 title="<?php echo e($produit->nom); ?>" class="item-title mbr-fonts-style display-5">
                                <a
                                    href="<?php echo e(route('shop.produit.show',compact('produit','shop'))); ?>"><?php echo e(\Illuminate\Support\Str::limit($produit->nom, 20, '...')); ?></a>
                            </h5>
                            <p style="min-height: 100px" class="mbr-text mbr-fonts-style display-7">
                                <?php echo e(\Illuminate\Support\Str::limit($produit->description, 100, '...')); ?></p>
                        </div>
                        <div class="mbr-section-btn item-footer">
                            <a href="<?php echo e(route('shop.produit.edit',compact('shop','produit'))); ?>" class="btn btn-primary"
                                style="margin-right: 2px;"><i class="fa fa-edit"></i></a>
                            <form style="display: inline;" method="POST"
                                action="<?php echo e(route('shop.produit.destroy',compact('produit','shop'))); ?>">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button style="display: inline;" class="btn btn-danger"><i
                                        class="fa fa-trash"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12">
                    <?php if($produits->currentPage()!=$produits->lastPage()): ?>
                    <a href="<?php echo e($produits->nextPageUrl()); ?>" class="btn btn-secondary pull-right mr-2">Page suivante</a>
                    <?php endif; ?>
                    <?php if($produits->currentPage() != 1): ?>
                    <a class="btn btn-secondary ml-2" href="<?php echo e($produits->previousPageUrl()); ?>"><span
                            class="mbrib-more-horizontal mbr-iconfont mbr-iconfont-btn"></span>Page précédente</a>
                    <?php endif; ?>
                </div>
            </div>
    </div>
    </section>
    <section data-bs-version="5.1" class="content11 cid-sIqE76THls" id="content11-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="mbr-section-btn align-center"><a class="btn btn-primary display-4"
                            href="<?php echo e(route('shop.produit.create',compact('shop'))); ?>"><span
                                class="mobi-mbri mobi-mbri-plus mbr-iconfont mbr-iconfont-btn"></span>Ajouter un
                            produit</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views/shop/catalogue.blade.php ENDPATH**/ ?>