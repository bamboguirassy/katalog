

<?php $__env->startSection('title','Commande '.$commande->numero); ?>;

<?php $__env->startSection('description',"La commande n° ".$commande->numero." chez ".$shop->nom); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-12">
        <section data-bs-version="5.1" class="content02 cid-sIYyERI2Kj" id="content02-3r">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-4 image-wrapper">
                        <img class="w-100" src="<?php echo e(asset('storage/shops/'.$shop->logo)); ?>" alt="<?php echo e($shop->logo); ?>">
                    </div>
                    <div class="col-12 col-md">
                        <div class="text-wrapper align-left">
                            <h3 class="mbr-section-title mbr-fonts-style mb-4 display-2"><strong><?php echo e($shop->nom); ?> -&gt;
                                    Commande n° <?php echo e($commande->numero); ?></strong></h3>
                            <p class="mbr-text mbr-fonts-style mb-4 display-7"></p>
                            <p>Voici les détails de la commande n° <b><?php echo e($commande->numero); ?></b> passée dans la
                                boutique
                                <b><?php echo e($shop->nom); ?></b>.
                            </p>
                            <p class="mbr-fonts-style text display-4">
                                <strong
                                    style="padding: 5px; border-radius: 15px; border-right: 2px solid #1C73BA; color: #1C73BA;">Statut
                                    actuel : <?php echo e($commande->etat); ?></strong>
                            </p>
                            <p></p>
                            <div class="mbr-section-btn mt-3">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(auth()->user()->type=="owner" && auth()->user()->id==$shop->user_id): ?>
                                <?php if($commande->etat=='En attente'): ?>
                                <form style="display: inline; float: right; margin-left: 3px;"
                                    action="<?php echo e(route('shop.commande.update',compact('shop','commande'))); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input hidden type="text" value="Acceptée" name="etat">
                                    <button class="btn btn-md btn-info display-4 m-0">
                                        <span class="fa fa-check-circle-o mbr-iconfont mbr-iconfont-btn"></span>
                                        Accepter</button>
                                </form>
                                <form style="display: inline; float: right; margin-left: 3px;"
                                    action="<?php echo e(route('shop.commande.update',compact('shop','commande'))); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input hidden type="text" value="Rejetée" name="etat">
                                    <button class="btn btn-md btn-danger display-4">
                                        <span class="mdi-navigation-cancel mbr-iconfont mbr-iconfont-btn"></span>
                                        Rejeter</button>
                                </form>
                                <?php endif; ?>
                                <?php if($commande->etat=='Acceptée'): ?>
                                <form style="display: inline; float: right; margin-left: 3px;"
                                    action="<?php echo e(route('shop.commande.update',compact('shop','commande'))); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input hidden type="text" value="Livrée" name="etat">
                                    <button class="btn btn-md btn-primary display-4">
                                        <span class="fa fa-check-circle-o mbr-iconfont mbr-iconfont-btn"></span>
                                        Livrer</button>
                                </form>
                                <?php endif; ?>

                                <?php endif; ?>
                                <?php if(auth()->user()->id!=$commande->user_id): ?>
                                <a class="btn btn-md btn-secondary display-4" href="tel:<?php echo e($commande->user->telephone); ?>">
                                    <span class="mobi-mbri mobi-mbri-phone mbr-iconfont mbr-iconfont-btn"></span>
                                    Contacter le client</a>
                                <?php elseif($commande->etat=='En attente'): ?>
                                <form style="display: inline; float: right; margin-left: 3px;"
                                    action="<?php echo e(route('shop.commande.update',['commande'=>$commande,'shop'=>$commande->shop])); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input hidden type="text" value="Annulée" name="etat">
                                    <button class="btn btn-md btn-danger display-4">
                                        <span class="mbri-close mbr-iconfont mbr-iconfont-btn">
                                        </span>Annuler
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section data-bs-version="5.1" class="info3 cid-sIYAlof4Zy" id="info3-3t">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="card col-12 col-lg-10">
                        <div class="card-wrapper">
                            <div class="card-box align-center">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section data-bs-version="5.1" class="table1 marketm4_table1 cid-sIYA66Ebd1" id="table1-3s">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-10">
                        <div class="text-center text-lg-left">
                            <h2 class="mbr-section-title mbr-bold mbr-fonts-style display-5">
                                Produits commandés</h2>
                        </div>
                        <div class="row justify-content-between no-gutters">
                            <div class="col-lg-12 tables">
                                <div class="row justify-content-center no-gutters">
                                    <?php $__currentLoopData = $commande->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4 col-10 column">
                                        <div class="table__title text-center text-sm-left border__bot px-3">
                                            <h3 class="title mbr-medium mbr-fonts-style display-7">
                                                <?php echo e($produit->produit->nom); ?></h3>
                                        </div>
                                        <div class="cell text-center text-sm-left border__bot">
                                            <p class="mbr-fonts-style mbr-text display-4">
                                                <?php echo e($produit->produit->prixUnitaire); ?> FCFA</p>
                                        </div>
                                        <div class="cell text-center text-sm-left border__bot">
                                            <p class="mbr-fonts-style mbr-text display-4"><?php echo e($produit->quantite); ?>

                                                unité(s)</p>
                                        </div>
                                        <div class="cell text-center text-sm-left border__bot">
                                            <p class="mbr-fonts-style mbr-text display-4">
                                                <?php echo e($produit->produit->prixUnitaire * $produit->quantite); ?> FCFA</p>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-lg-3 flex-column text-center text-lg-left mt-5 content__block">
                                <h3 class="mbr-fonts-style title__text display-7"><strong>Montant</strong> :
                                    <?php echo e($montant); ?> FCFA
                                </h3>
                                <p class="mbr-fonts-style text display-4"><strong>Statut : <?php echo e($commande->etat); ?></strong>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bambogroup\katalog\resources\views\shop\commande\show.blade.php ENDPATH**/ ?>